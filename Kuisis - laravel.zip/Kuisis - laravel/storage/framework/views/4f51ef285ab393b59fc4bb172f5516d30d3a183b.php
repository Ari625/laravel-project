
<?php $__env->startSection('container'); ?>
    
<div class="card rounded-3 shadow-sm p-3 mb-3 bg-body-tertiary rounded border border-2" style="width: 25rem;">
  <div class="card-body">
    <h5 class="card-title text-uppercase">Kuis harian</h5>
    <h6 class="card-subtitle text-white text-muted mt-3 nav-item" style="color:white;"> </h6>
    <h6 class="card-subtitle text-white text-muted nav-item" style="color:white;"> </h6>
      <a href="/list-quiz" class="card-link btn btn-primary mt-4 fw-bolder" role="button" align="right">Mulai</a>
  </div>
</div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\Kuisis\resources\views/home-page.blade.php ENDPATH**/ ?>