
<?php $__env->startSection('container'); ?>

<div class="row justify-content-center">
  <div class="col-md-4">
<main class="form-signin w-80 ">
<h2 class="text-center text-uppercase">registration</h2>
<form class="row g-3" action="/registration" method="post">
  <?php echo csrf_field(); ?>
   <div class="col-md-6">
     <label for="name" class="form-label <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Name</label>
     <input type="name" class="form-control" id="name" name="name" required value="<?php echo e(old('name')); ?>">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="invalid-feedback">
      <?php echo e($message); ?>

     </div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>
   <div class="col-md-6">
     <label for="email" class="form-label" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>Email</label>
     <input type="email" class="form-control" id="email" name="email" required value="<?php echo e(old('email')); ?>">
     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="invalid-feedback">
      <?php echo e($message); ?>

     </div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>
   <div class="col-md-6">
     <label for="password" class="form-label" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>Password</label>
     <input type="password" class="form-control" id="password" name="password" required>
     <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="invalid-feedback">
      <?php echo e($message); ?>

     </div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>
   
   <div class="col-12">
     <button type="submit" class="btn btn-primary form-signin">Register</button>
   </div>
 </form>
 <h6 class="mt-3 ">Already registered? 
  <a href="/login" class="text">Login</a>
</h6>
</main>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sign', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\Kuisis\resources\views/registration.blade.php ENDPATH**/ ?>