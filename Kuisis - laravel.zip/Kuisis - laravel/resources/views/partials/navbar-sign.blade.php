<ul class="nav nav-pills nav-fill gap-2 p-1 small bg-primary shadow-sm" id="pillNav2" role="tablist" style="--bs-nav-link-color: var(--bs-white); --bs-nav-pills-link-active-color: var(--bs-primary); --bs-nav-pills-link-active-bg: var(--bs-white);">
   <li class="nav-item">
   <button class="shadow-sm rounded-2 mb-3 mt-2" style="color: blue; border : white;">
      <font class="font-bold text-uppercase fw-bolder" size="6px" style="color: #00A3ff;">KUISIS</font>
   </button>
   </li>
   <li class="nav-item" role="presentation">
      <a href="/register" class="mt-2 mb-3 btn btn-primary" role="button">
         <font size="4px" class="text-uppercase"></font>
      </a>
   </li>
   <li class="nav-item" role="presentation">
      <a href="/register" class="mt-2 mb-3 btn btn-primary" role="button">
         <font size="4px" class="text-uppercase"></font>
      </a>
   </li>
</ul>